package com.niit.SkillMappingBackEnd.Entity;

import com.niit.SkillMappingBackEnd.Utility.DbConnect;

public class Testing {

	public static void main(String[] args) {
		DbConnect.connect();
	}

}
