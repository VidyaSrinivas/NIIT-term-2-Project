package com.niit.SkillMappingBackEnd.Entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.niit.SkillMappingBackEnd.Utility.Validation;

public class Users {

	private int EmpId;
	private String name;
	private String dateofbirth;
	private String Gender;
    private String address;
	private String qualification;
	private String emailId;
	private String contactNo;
	private String department;
	private String Supervicer;
	private String password;
	private String role;
	private String Authentication;

	
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getrole() {
		return role;
	}

	public void setrole(String role) {
		this.role = role;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		this.Gender = gender;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getSupervicer() {
		return Supervicer;
	}

	public void setSupervicer(String supervicer) {
		Supervicer = supervicer;
	}

	public String getAuthentication() {
		return Authentication;
	}

	public void setAuthentication(String authentication) {
		Authentication = authentication;
	}

	
	
	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		this.EmpId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	
	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		Validation validate=new Validation();
		if(validate.validateEmail(emailId))
		    this.emailId = emailId;
		else
		{
			System.out.println("Invalid email");
			System.exit(0);
		}
	}
	
	public String getcontactNo() {
		return contactNo;
	}

	public void setcontactNo(String contactNo) {
		/*//Validation validate=new Validation();
		if(validate.validateContactNo(contactNo))
		   
		else
		{
			System.out.println("Invalid Contact number");
			System.exit(0);
		}*/
		 this.contactNo = contactNo;
	}


	public String getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(String dateofbirth) {
		this.dateofbirth = dateofbirth;
	}

	
}



