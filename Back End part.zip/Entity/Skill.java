package com.niit.SkillMappingBackEnd.Entity;

public class Skill {
	private int EmpId;
	private int id ;
	private String skillname;
	private String certification;
	private int experienceyear;
	public int getEmpId() {
		return EmpId;
	}
	
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSkillname() {
		return skillname;
	}
	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}
	public String getCertification() {
		return certification;
	}
	public void setCertification(String certification) {
		this.certification = certification;
	}
	public int getExperienceyear() {
		return experienceyear;
	}
	public void setExperienceyear(int experienceyear) {
		this.experienceyear = experienceyear;
	}

}
