package com.niit.SkillMappingBackEndEntity.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.niit.SkillMappingBackEnd.Entity.Users;
import com.niit.SkillMappingBackEnd.Entity.Skill;
import com.niit.SkillMappingBackEnd.Utility.DbConnect;

public class SkillDAOImpl {
	static Connection con = null;

	public SkillDAOImpl() {
		con = DbConnect.connect();
	}
	
	
	//inserting user details
		public boolean insertUser(Skill skill) {
			Skill user1 = new Skill();
			try {
				PreparedStatement ps = con.prepareStatement("INSERT INTO Skill VALUES (?,?,?,?,?)");
				ps.setInt(1, skill.getEmpId());
				ps.setInt(2, skill.getId());
				ps.setString(3, skill. getSkillname());
				ps.setString(4, skill.getCertification());
				ps.setInt(5, skill.getExperienceyear());
		
				int i = ps.executeUpdate();
				if (i > 0) {
					System.out.println("skills of employee details  inserted successful");

					return true;
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return false;
		}
		
		
		
		//updating users details
		public boolean updateskill(Skill skill) {
			
			int rowsUpdated = 0;
			try {
				PreparedStatement ps = con.prepareStatement("UPDATE Skill SET skillname=? WHERE id=?");
				ps.setString(1, skill.getSkillname());
				ps.setInt(2, skill.getId());
				rowsUpdated = ps.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			if (rowsUpdated > 0) {
				System.out.println("An existing  was updated successfully!");
				return true;
			}
			return false;
		}
		
		//Retrieving user by name
		public Skill getSkillByname(String Skillname) {
			Skill skill = new Skill();

			try {

				PreparedStatement ps = con.prepareStatement("select * from Skill where Skillname=?");
				ps.setString(1, Skillname);
				ResultSet rs = ps.executeQuery();
				
				if (rs.next()) {
					skill.setEmpId(rs.getInt(1));
					skill.setId(rs.getInt(2));
					skill.setSkillname(rs.getString(3));
					skill.setCertification(rs.getString(4));
					skill.setExperienceyear(rs.getInt(5));
					
				}

			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return skill;
		}
		
		public Skill getSkillById(int empid) {
			Skill skill = new Skill();

			try {

				PreparedStatement ps = con.prepareStatement("select * from Skill where empid=?");
				ps.setInt(1, empid);
				ResultSet rs = ps.executeQuery();
				
				if (rs.next()) {
					skill.setEmpId(rs.getInt(1));
					skill.setId(rs.getInt(2));
					skill.setSkillname(rs.getString(3));
					skill.setCertification(rs.getString(4));
					skill.setExperienceyear(rs.getInt(5));
					
				}

			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return skill;
		}
		
		//Deleting user by Id
		public boolean deleteskill(int id) {

			int rowsUpdated = 0;
			try {

				PreparedStatement ps = con.prepareStatement("delete from skill where Id=?");
				ps.setInt(1, id);
				rowsUpdated = ps.executeUpdate();
				if (rowsUpdated > 0) {
					System.out.println("employee details  deleted successfully");

					return true;

				}
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
			return false;

		}
		
//  displayind the user report using list
		public static List<Skill> getAllUsers(String Skillname){  
			List<Skill> list=new ArrayList<Skill>();  
  
			try{  

				PreparedStatement ps=con.prepareStatement("select * from skill where skillname=? "); 
				ps.setString(1, Skillname);
				ResultSet rs=ps.executeQuery();  
				while(rs.next()){  
					Skill skill=new Skill(); 
					skill.setEmpId(rs.getInt(1));
					skill.setId(rs.getInt(2));
					skill.setSkillname(rs.getString(3));
					skill.setCertification(rs.getString(4));
					skill.setExperienceyear(rs.getInt(5));
					
					list.add(skill);  
				}    
			}catch(Exception e){e.printStackTrace();}  

			return list;  
		}  
		
		
		/*public static List<Skill> getskillByname(){  
			List<Skill> list=new ArrayList<Skill>();  

			try{  

				PreparedStatement ps=con.prepareStatement("select * from skill where skillname=?");  
				ResultSet rs=ps.executeQuery();  
				while(rs.next()){  
					Skill skill=new Skill(); 
					skill.setEmpId(rs.getInt(1));
					skill.setId(rs.getInt(2));
					skill.setSkillname(rs.getString(3));
					skill.setCertification(rs.getString(4));
					skill.setExperienceyear(rs.getInt(5));
					
					list.add(skill);  
				}  
				con.close();  
			}catch(Exception e){e.printStackTrace();}  

			return list;  
		} */ 
	}



