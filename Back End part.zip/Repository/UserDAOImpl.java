package com.niit.SkillMappingBackEndEntity.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.niit.SkillMappingBackEnd.Entity.Users;
import com.niit.SkillMappingBackEnd.Utility.DbConnect;


public class UserDAOImpl {
static Connection con = null;

public UserDAOImpl() {
		con = DbConnect.connect();
	}
	//inserting user details
	public boolean insertUser(Users user) {
		Users user1 = new Users();
		try {
			PreparedStatement ps = con.prepareStatement("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setInt(1, user.getEmpId());
			ps.setString(2, user.getName());
			ps.setString(3, user. getDateofbirth());
			ps.setString(4, user.getGender());
			ps.setString(5, user.getAddress());
			ps.setString(6, user.getQualification());
			ps.setString(7, user.getEmailId());
			ps.setString(8, user.getcontactNo());
			ps.setString(9, user.getDepartment());
			ps.setString(10, user.getSupervicer());
			ps.setString(11, user.getPassword());
			ps.setString(12, user.getrole());
			ps.setString(13, user.getAuthentication());
	
			
			int i = ps.executeUpdate();
			if (i > 0) {
				System.out.println("employee details  inserted successful");

				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;
	}
	//updating users details
	public boolean updateUser(Users user) {
		// Users user1=new Users();
		int rowsUpdated = 0;

		try {
			PreparedStatement ps = con.prepareStatement("UPDATE Users SET name=? WHERE empId=?");
			// user1 = getUserById(uId);
			ps.setString(1, user.getName());
			ps.setInt(2, user.getEmpId());
			// ps.setString(4, user1.getEmailId());

			rowsUpdated = ps.executeUpdate();
		} catch (SQLException e) {

			e.printStackTrace();
		}
		if (rowsUpdated > 0) {
			System.out.println("An existing users was updated successfully!");
			return true;

		}
		return false;
	}
	
	
	
	
	
	//Retrieving user by Id
	public Users getUserById(int uid) {
		Users user = new Users();

		try {

			PreparedStatement ps = con.prepareStatement("select * from users where empId=?");
			ps.setInt(1, uid);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user.setEmpId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setDateofbirth(rs.getString(3));
				user.setGender(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setQualification(rs.getString(6));
				user.setEmailId(rs.getString(7));
				user.setcontactNo(rs.getString(8));
				user.setDepartment(rs.getString(9));
				user.setSupervicer(rs.getString(10));
				user.setPassword(rs.getString(11));
				user.setrole(rs.getString(12));
				user.setAuthentication(rs.getString(13));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return user;
	}
	
	
	// getting details of Authentication details for hr
	public Users getUserByauthentication(String authentication) {
		Users user = new Users();
		try {

			PreparedStatement ps = con.prepareStatement("select * from users where Authentication=?");
			ps.setString(1, authentication);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				user.setEmpId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setDateofbirth(rs.getString(3));
				user.setGender(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setQualification(rs.getString(6));
				user.setEmailId(rs.getString(7));
				user.setcontactNo(rs.getString(8));
				user.setDepartment(rs.getString(9));
				user.setSupervicer(rs.getString(10));
				user.setPassword(rs.getString(11));
				user.setrole(rs.getString(12));
				user.setAuthentication(rs.getString(13));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return user;
	}
	
	
	//Deleting user by Id
	public boolean deleteUser(int id) {
		int rowsUpdated = 0;
		try {

			PreparedStatement ps = con.prepareStatement("delete from users where empId=?");
			ps.setInt(1, id);
			rowsUpdated = ps.executeUpdate();
			if (rowsUpdated > 0) {
				System.out.println("employee details  deleted successfully");

				return true;

			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		return false;

	}
	
	// login user checking
	public boolean authorizeUser(int empId, String pwd)
	{
		boolean flag=false;
		Users u = new Users();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from users where empId=? and password=?");
			ps.setInt(1, empId);
			ps.setString(2, pwd);
			ResultSet rs =ps.executeQuery();
			flag = rs.next();
			
			 /* ps=con.prepareStatement("SELECT password from user where empId=?");  
			  ps.setInt(2, empId);
				ps.setString(1, pwd);
		       if(empId==u.getEmpId() && pwd.equals(u.getPassword())){  
		            return true;  
		        }
		else {  
		            return false;  
		        }  */
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		return flag;

	}
	
	
	public static List<Users> getAllUsers(){  
		List<Users> list=new ArrayList<Users>();  

		try{  

			PreparedStatement ps=con.prepareStatement("select * from users");  
			ResultSet rs=ps.executeQuery();  
			while(rs.next()){  
				Users user=new Users();  
				user.setEmpId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setDateofbirth(rs.getString(3));
				user.setGender(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setQualification(rs.getString(6));
				user.setEmailId(rs.getString(7));
				user.setcontactNo(rs.getString(8));
				user.setDepartment(rs.getString(9));
				user.setSupervicer(rs.getString(10));
				user.setPassword(rs.getString(11));
				user.setrole(rs.getString(12));
				user.setAuthentication(rs.getString(13));
				list.add(user);  
			}  
			  
		}catch(Exception e){e.printStackTrace();}  

		return list;  
	}

	public static List<Users> getAllUsersauthentication(String authentication){  
		List<Users> list=new ArrayList<Users>(); 


		try{  

			PreparedStatement ps=con.prepareStatement("select * from users where Authentication=?");  
			ps.setString(1, authentication);
			ResultSet rs = ps.executeQuery();

			while(rs.next()){  
				Users user=new Users();  
				user.setEmpId(rs.getInt(1));
				user.setName(rs.getString(2));
				user.setDateofbirth(rs.getString(3));
				user.setGender(rs.getString(4));
				user.setAddress(rs.getString(5));
				user.setQualification(rs.getString(6));
				user.setEmailId(rs.getString(7));
				user.setcontactNo(rs.getString(8));
				user.setDepartment(rs.getString(9));
				user.setSupervicer(rs.getString(10));
				user.setPassword(rs.getString(11));
				user.setrole(rs.getString(12));
				user.setAuthentication(rs.getString(13));
				list.add(user);  
			}  
			  
		}catch(Exception e){e.printStackTrace();}  

		return list;  
	}
}
