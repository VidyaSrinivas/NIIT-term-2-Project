package com.niit.SkillMappingBackEnd.TestCase;

import org.junit.Test;

import com.niit.SkillMappingBackEnd.Entity.Users;
import com.niit.SkillMappingBackEndEntity.Repository.UserDAOImpl;
import static org.junit.Assert.assertEquals;
import java.util.List;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

	public class UserTestcase {
		private static UserDAOImpl userDao = new UserDAOImpl();
		private Users user1 = new Users();
		
		@BeforeClass
		public static void init() {
			userDao = new UserDAOImpl();
		}
	//@Ignore

		@Test
		public void testInsertUser() {
			boolean flag;
			user1 = new Users();
		user1.setEmpId(2901);
			user1.setName("harish");
			user1.setDateofbirth("2311995");
			user1.setGender("Male");
			user1.setAddress("bangalore");
			user1.setQualification("BE");
			user1.setEmailId("reem@gmail.com");
			user1.setcontactNo("998011221");
			user1.setDepartment("dept1");
			user1.setSupervicer("geeta");
			user1.setPassword("123456");
			user1.setrole("Employee");
			user1.setAuthentication("NotApproved");
			flag = userDao.insertUser(user1);
			assertEquals("Failed to insert userdetails!", true, flag);
			
		}

		
	//@Ignore
		@Test
		public void testgetUserById() {
			user1 = userDao.getUserById(2900);
			assertEquals("Failed to get User !", "harish", user1.getName());
		}
	@Ignore
	@Test
	public void testgetUserByauthentication() {
		user1 = userDao.getUserByauthentication("not approved");
		assertEquals("Failed to get User !", "joseph", user1.getName());
	}

	 @Ignore
		@Test
		public void testUpdateUser() {

			user1 = userDao.getUserById(2900);
			user1.setName("vidya");
			boolean flag = userDao.updateUser(user1);
			assertEquals("Failed to update userdetails!", true, flag);
		}

		@Ignore
		@Test
		public void testDeleteUser() {
			boolean flag = userDao.deleteUser(115);
			assertEquals("Failed to delete userdetails!", true, flag);

		}
		@Ignore
		@Test
		 
		public void testvaliduser() {
			boolean flag = userDao.authorizeUser(111, "521148");
			assertEquals("Failed to delete authorizer!", true, flag);
	
		}
		@Ignore
		@Test
		 public void testlistuser() {
			List<Users> list = userDao.getAllUsers();
			assertEquals("Failed to listusers!",6,list.size());
		}
		@Ignore
		@Test
		 public void testlistuserauthentication() {
			List<Users> list = userDao.getAllUsersauthentication("Approved");
			assertEquals("Failed to listusers!",4,list.size());
		}
		@Test
		 public void testlistuserauthentication1() {
			List<Users> list = userDao.getAllUsersauthentication("Not Approved");
			assertEquals("Failed to listusers!",1,list.size());
		}

		}
		 
		
		
		
		
		
			