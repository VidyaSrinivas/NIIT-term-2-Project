package com.niit.SkillMappingBackEnd.TestCase;

import static org.junit.Assert.*;

import java.util.List;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

import com.niit.SkillMappingBackEnd.Entity.Users;
import com.niit.SkillMappingBackEnd.Entity.Skill;
import com.niit.SkillMappingBackEndEntity.Repository.SkillDAOImpl;

	public class SkillTestCase {
		private static SkillDAOImpl skillDao = new  SkillDAOImpl();
		private Skill skill = new Skill();
		
		@BeforeClass
		public static void init() {
			skillDao = new  SkillDAOImpl();
		}
		@Ignore

		@Test
		public void testInsertskill() {
			boolean flag;
			skill = new Skill();
		    skill.setEmpId(2900);
			skill.setId(55);
			skill.setSkillname("java");
			skill.setCertification("c1");
			skill.setExperienceyear(5);
			
			flag = skillDao.insertUser(skill);
			assertEquals("Failed to insert userdetails!", true, flag);
			
	
		}


	@Ignore
		@Test
		public void testgetskillById() {
			skill = skillDao.getSkillByname("C++");
			assertEquals("Failed to get User !", 2, skill.getId());
		}
	
	

		//@Ignore
		@Test
		public void testUpdateskill() {

			skill = skillDao.getSkillById(111);
			skill.setSkillname("JEE");
			boolean flag = skillDao.updateskill(skill);
			assertEquals("Failed to update userdetails!", true, flag);
		}


		@Ignore
		@Test
		public void testDeleteUser() {

			boolean flag = skillDao.deleteskill(3);
			assertEquals("Failed to delete userdetails!", true, flag);
		}
		
		
		@Ignore
		@Test
		 public void testlistuser() {
			List<Skill> list = skillDao.getAllUsers("java");
			assertEquals("Failed to listusers!",2,list.size());
		}
	

}